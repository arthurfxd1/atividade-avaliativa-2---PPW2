O objetivo deste projeto é projetar, desenvolver e documentar uma API para gerenciar projetos e suas respectivas tarefas, 
A aplicação foi desenvolvida utilizando spring boot, spring data jpa e mysql, seguindo os princípios REST.

---

tecnologias Utilizadas
- Java 17
- Spring Boot 3
- Spring Data JPA (Hibernate)
- MySQL
- Maven
- Tomcat (embutido no Spring Boot)



