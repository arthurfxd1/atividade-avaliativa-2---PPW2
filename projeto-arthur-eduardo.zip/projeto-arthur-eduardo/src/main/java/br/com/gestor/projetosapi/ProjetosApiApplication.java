package br.com.gestor.projetosapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetosApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetosApiApplication.class, args);
	}

}
