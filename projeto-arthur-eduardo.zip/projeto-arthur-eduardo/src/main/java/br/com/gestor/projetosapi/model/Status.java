package br.com.gestor.projetosapi.model;

public enum Status {
    PENDENTE,
    EM_ANDAMENTO,
    CONCLUIDA
}
