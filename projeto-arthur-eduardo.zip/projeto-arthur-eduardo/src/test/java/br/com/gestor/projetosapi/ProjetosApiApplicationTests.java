package br.com.gestor.projetosapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetosApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
